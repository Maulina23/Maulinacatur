<html>
    <head>
        <title>Halaman Beranda</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>
      <header>
        <ul>
          <a href="index.php"><li>Beranda</li></a>
          <a href="artikel.php"><li>Artikel</li></a>
          <a href="keluar.php"><li>keluar</li></a>


        </ul>
      </header>

      <section>
        <center>
            <font style="font-size:40px;">Selamat Datang di halaman Artikel</font>
            <font style="font-size:16px;">
              <br>
              </br>
            </font>
        </center>
      </section>

      <footer>
        Copyright &copy; 2018 Maulina Catur Wulandari X RPL 1
      </footer>

    </body>
</html>
