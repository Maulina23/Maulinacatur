<?php

$conn= mysqli_connect("localhost","root","","register","login");
function registrasi($post){
  global $conn;
  $username= htmlspecialchars ($post["username"]);
  $password= htmlspecialchars($post["password"]);
  $password2= htmlspecialchars($post["password2"]);
  //query insert data
  $query = "INSERT INTO user
              VALUES
                ('','$username','$password','password2')
                  ";
                  mysqli_query($conn,$query);

                  return mysqli_affected_rows($conn);
                }
 ?>
