<html>
    <head>
        <title><br>Halaman Beranda</title>
        <link rel="stylesheet" type="text/css" href="styles.css">
    </head>
    <body>
      <header>
        <ul>
          <a href="index.php"><li>Beranda</li></a>
          <a href="artikel.php"><li>Artikel</li></a>
          <a href="keluar.php"><li>keluar</li></a>


            <div class="img">
      <a target="blank" href="03.jpg">
      <img src="2.jpg" alt="Trolltunga Norway"  width="400" height="400">
      <a target="blank" href="2.jpg">
      <img src="7.jpg" alt="Trolltunga Norway"  width="400" height="600">
      <a target="blank" href="7.jpg">
      <img src="23.jpg" alt="Trolltunga Norway"  width="400" height="400">

        </ul>
      </header>

      <section>
        <center>
            <font style="font-size:36px;color:black;font-family:justiceleague;">Selamat Datang di halaman Beranda</font>
        </center>
      </section>

    </body>
</html>
