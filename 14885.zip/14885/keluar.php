 <?php
include 'masuk.php';
session_start();
if (session_destroy()) {
  header("Location:halaman_login.php");
}
 ?>
