<?php
require 'proses_artikel.php';
// ambil dat di url--
$id = $_GET["id"];
// query data mahasiswa berdasarka ID
$artikel = query("SELECT * FROM artikel WHERE id = $id")[0];
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Read More</title>
  </head>
  <link rel="stylesheet" href="css/stylereadmore.css">

  <body>
        <div class="sidebar">
      <ul>
        <li><a href="dashboard.php">Berita</a></li>
        <li><a href="artikel_tambah.php">Tambah Berita</a></li>
        <li><a href="daftaruser.php">Daftar User</a></li>
        <li><a href="about me.php">About Penulis</a></li>
        </ul>
    </div>
    
    <div class="bgjudul">
      <p class="merek">Sinopdrakor</p>
    </div>
    
    <div class="atas">
      <button class="tulisatas">Logout</button>
    </div>

    <section id="bighit">
      <div class="bts">
        <div class="box">
          <article class="" id="main-col">
             <center><p class="judul"><?= $artikel["judul"]; ?></p></center>
                <br>
              <p><?= $artikel["isi"];  ?></p><br><br><br>
              <p class="penulis"><i>Oleh : <?=$artikel["penulis"];  ?></i></p>
              <a href="tampilberita.php"><button class="read">Kembali</button></a>
          </article>
        </div>
      </div>
    </section>
  </body>
</html>
