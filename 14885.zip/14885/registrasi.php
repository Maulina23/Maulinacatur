<!DOCTYPE html>
<html>
    <head>

      <title>Register</title>
    </head>
    <body>
        <form class="" action="" method="post">
            <table>
                <tr>
                    <td>username</td>
                    <td><input type="text" name="username" value=""></td>
                  </tr>
                  <tr>
                      <td>Password</td>
                      <td><input type="password" name="password" value=""
                        ></td>
                </tr>
                <tr>
                    <td><a href="halaman_login.php">Halaman Login</a></td>
                    <td><input type="submit" name="submit" value="submit"></td>
                  </tr>
                </table>
              </form>

  </body>
</html>
<?php
 include 'function.php';
 if(@$_POST['submit']) {
   $username=@$_POST['username'];
   $password=@$_POST['password'];
   mysqli_query($conn,"INSERT INTO user (Nama,Password) VALUES('$username','$password')");
  ?>
  <script type="text/javascript">
    alert("data tersimpan");
    window.location.href="halaman_login.php"
    </script>
    <?php
 }
